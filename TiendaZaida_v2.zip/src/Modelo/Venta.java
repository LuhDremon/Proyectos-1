
package Modelo;

public class Venta {
    private int id;
    private String tipo;
    private double total;
    private String fecha;
    private int cantidad;
    private String dni_cliente;
    
    public Venta(){
    }

    public Venta(int id, String tipo, double total, String fecha, int cantidad) {
        this.id = id;
        this.tipo = tipo;
        this.total = total;
        this.fecha = fecha;
        this.cantidad = cantidad;
    }

    public String getDni_cliente() {
        return dni_cliente;
    }

    public void setDni_cliente(String dni_cliente) {
        this.dni_cliente = dni_cliente;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    

    
}
