
package Modelo;

import java.util.Date;

public class Proveedor {
    private int id;
    private String ruc;
    private String nombre;
    private String telefono;
    private Date primera_entrega;
    private Date ultima_entrega;
    
    public Proveedor(){
        
    }

    public Proveedor(int id, String ruc, String nombre, String telefono) {
        this.id = id;
        this.ruc = ruc;
        this.nombre = nombre;
        this.telefono = telefono;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Date getPrimera_entrega() {
        return primera_entrega;
    }

    public void setPrimera_entrega(Date primera_entrega) {
        this.primera_entrega = primera_entrega;
    }

    public Date getUltima_entrega() {
        return ultima_entrega;
    }

    public void setUltima_entrega(Date ultima_entrega) {
        this.ultima_entrega = ultima_entrega;
    }
    
}
