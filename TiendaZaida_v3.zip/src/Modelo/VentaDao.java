
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class VentaDao {
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    int r;
    
    public int IdVenta(){
        int id = 0;
        String sql = "SELECT MAX(CODIGO) FROM PEDIDO";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return id;
    }
    
    public boolean RegistrarVenta(Venta v){
        String sql = "INSERT INTO PEDIDO (CODIGO, CANT_COMPRA, MONTO_TOTAL, FECHA, TIPO_PEDIDO, DNI_CLIENTE, TIPO_PAGO) VALUES (?,?,?,?,?,?,?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, v.getId());
            ps.setInt(2, v.getCantidad());
            ps.setDouble(3,v.getTotal());
            ps.setString(4, v.getFecha());
            ps.setString(5, v.getTipo());
            ps.setString(6, v.getDni_cliente());
            ps.setString(7, v.getTipo_pago());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }finally{
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println(e.toString());
            }
        }
        return false;
    }
    
    public int IdDetalle(){
        int id = 0;
        String sql = "SELECT MAX(ID) FROM DETALLE";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return id;
    }
    
    public int RegistrarDetalle(Detalle Dv){
       String sql = "INSERT INTO detalle (id, id_pro, cantidad, precio, id_venta) VALUES (?,?,?,?,?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, Dv.getId());
            ps.setInt(2, Dv.getId_pro());
            ps.setInt(3, Dv.getCantidad());
            ps.setDouble(4, Dv.getPrecio());
            ps.setInt(5, Dv.getId_venta());
            ps.execute();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }finally{
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println(e.toString());
            }
        }
        return r;
    }
    
    public boolean ActualizarStock(int cant, int id){
        String sql = "UPDATE productos SET stock = ? WHERE id = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1,cant);
            ps.setInt(2, id);
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
    }
    
    public List Listarventas(){
       List<Venta> ListaVenta = new ArrayList();
       String sql = "SELECT * FROM pedido";
       try {
           con = cn.getConnection();
           ps = con.prepareStatement(sql);
           rs = ps.executeQuery();
           while (rs.next()) {               
               Venta vent = new Venta();
               vent.setId(rs.getInt("codigo"));
               vent.setTipo(rs.getString("TIPO_PEDIDO"));
               vent.setTotal(rs.getDouble("MONTO_TOTAL"));
               vent.setCantidad(rs.getInt("CANT_COMPRA"));
               vent.setFecha(rs.getDate("FECHA").toString());
               vent.setDni_cliente(rs.getString("DNI_CLIENTE"));
               vent.setTipo_pago(rs.getString("TIPO_PAGO"));
               ListaVenta.add(vent);
           }
       } catch (SQLException e) {
           System.out.println(e.toString());
       }
       return ListaVenta;
   }
    
    public Venta BuscarVenta(int id){
        Venta cl = new Venta();
        String sql = "SELECT * FROM PEDIDO WHERE codigo = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                cl.setId(rs.getInt("codigo"));
                cl.setCantidad(rs.getInt("CANT_COMPRA"));
                cl.setTotal(rs.getDouble("MONTO_TOTAL"));
                cl.setFecha(rs.getDate("fecha").toString());
                cl.setTipo(rs.getString("TIPO_PEDIDO"));
               cl.setDni_cliente(rs.getString("DNI_CLIENTE"));
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return cl;
    }   

    public List ListarDetalleVentas(){
        List<Object[]> lista = new ArrayList<>();
       String sql = "SELECT  prd.NOMBRE, prd.PRECIO PRECIO_U, SUM(dtl.CANTIDAD) Cantidad, SUM(dtl.PRECIO) PRECIO " +
                    "FROM DETALLE dtl " +
                    "INNER JOIN PRODUCTO prd ON dtl.ID_PRO = prd.CODIGO_PROD " +
                    "INNER JOIN PEDIDO pd ON dtl.ID_VENTA = pd.CODIGO " +
                    "GROUP BY prd.CODIGO_PROD, prd.NOMBRE, prd.PRECIO";
       try {
           con = cn.getConnection();
           ps = con.prepareStatement(sql);
           rs = ps.executeQuery();
           while (rs.next()) {
               Object[] ob = new Object[4];
                ob[0] = rs.getString("Nombre");
                ob[1] = rs.getString("PRECIO_U");
                ob[2] = rs.getString("Cantidad");
                ob[3] = rs.getString("PRECIO");
                lista.add(ob);
           }
           return lista;
       } catch (SQLException e) {
           System.out.println(e.toString());
       }
       return lista;
   }

}
